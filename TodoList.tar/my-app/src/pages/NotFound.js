import React from 'react'

export const NotFound = () => {
  return (
    <div>
      <h3>Ошибка 404: Страница не найдена</h3>
    </div>
  )
}
